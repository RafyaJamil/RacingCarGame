﻿using Game.Core;
using Game.Entities;
using Game.Movements;
using Game.Properties;
using Game.Systems;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Game
{
    public partial class RacingCar : Form
    {
        Game.Core.Game game = new Game.Core.Game();
        PhysicsSystem physics = new PhysicsSystem();
        CollisionSystem collisions = new CollisionSystem();
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        Image roadImage;
        Image sideImage;
        Image[] enemyCarImages;

        float laneWidth = 100f;
        float[] lanes;
        float roadX;
        float roadWidth;

        Random random = new Random();

        int enemyCounter = 0;
        int enemyInterval = 60;

        int boosterCounter = 0;
        int boosterInterval = 180;

        float fuel = 100f;
        const float maxFuel = 100f;

        int score = 0;
        const int maxScore = 70;

        int framesWithoutBooster = 0;
        const int framesFor5Seconds = 300;

        public RacingCar()
        {
            InitializeComponent();
            DoubleBuffered = true;

            roadImage = Resources.Roadimage;
            sideImage = Resources.roadsidebuildings;

            enemyCarImages = new Image[]
            {
                Resources.pinkCar,
                Resources.blueCar,
                Resources.greenCar,
                Resources.whiteTruck
            };

            roadWidth = laneWidth * 3;
            roadX = (ClientSize.Width - roadWidth) / 2;

            lanes = new float[]
            {
                roadX + laneWidth * 0.5f,
                roadX + laneWidth * 1.5f,
                roadX + laneWidth * 2.5f
            };

            SetupGame();
            SetupTimer();
        }

        void SetupGame()
        {
            game.AddObject(new Player
            {
                Position = new PointF(lanes[1], 420),
                Size = new Size(100, 100),
                Sprite = Resources.DriverCar,
                Movement = new KeyboardMovement()
            });
        }

        void SetupTimer()
        {
            timer.Interval = 16;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.DrawImage(sideImage, 0, 0, (int)roadX, ClientSize.Height);
            g.DrawImage(roadImage, roadX, 0, (int)roadWidth, ClientSize.Height);

            game.Draw(g);
            DrawHUD(g);
        }

        void Timer_Tick(object sender, EventArgs e)
        {
            framesWithoutBooster++;
            if (framesWithoutBooster >= framesFor5Seconds)
            {
                fuel -= 10;
                if (fuel < 0) fuel = 0;
                framesWithoutBooster = 0;
            }

            enemyCounter++;
            if (enemyCounter >= enemyInterval)
            {
                SpawnEnemy();
                enemyCounter = 0;
            }

            boosterCounter++;
            if (boosterCounter >= boosterInterval)
            {
                SpawnBooster();
                boosterCounter = 0;
            }

            game.Update(new GameTime());
            physics.Apply(game.Objects.ToList());
            collisions.Check(game.Objects.ToList());
            game.Cleanup();

            Player player = game.Objects.OfType<Player>().FirstOrDefault();
            if (player != null)
            {
                if (player.Position.X < lanes[0])
                    player.Position = new PointF(lanes[0], player.Position.Y);
                if (player.Position.X > lanes[2])
                    player.Position = new PointF(lanes[2], player.Position.Y);
            }

            if (fuel <= 0)
            {
                timer.Stop();
                MessageBox.Show("LEVEL FAILED!");
            }

            if (score >= maxScore)
            {
                timer.Stop();
                MessageBox.Show("LEVEL COMPLETE!");
            }

            Invalidate();
        }

        void SpawnEnemy()
        {
            int lane = random.Next(3);
            game.AddObject(new Enemy
            {
                Position = new PointF(lanes[lane], -120),
                Size = new Size(100, 100),
                Velocity = new PointF(0, 5),
                Sprite = enemyCarImages[random.Next(enemyCarImages.Length)]
            });
        }

        void SpawnBooster()
        {
            int lane = random.Next(3);
            game.AddObject(new EnergyBooster
            {
                Position = new PointF(lanes[lane], -60),
                Size = new Size(50, 50),
                Velocity = new PointF(0, 4),
                Sprite = Resources.energy
            });
        }

        void DrawHUD(Graphics g)
        {
            float hudX = roadX + roadWidth + 30;

            int barWidth = 60;
            int barHeight = 260;

            int fuelY = 80;
            int scoreY = fuelY + barHeight + 50;

            Font titleFont = new Font("Arial", 14, FontStyle.Bold);

            // FUEL
            g.DrawString("FUEL", titleFont, Brushes.White, hudX + 5, fuelY - 30);
            g.FillRectangle(Brushes.DarkGray, hudX, fuelY, barWidth, barHeight);

            float fuelFill = (fuel / maxFuel) * barHeight;
            Brush fuelBrush = fuel <= 30 ? Brushes.Red : Brushes.Lime;

            g.FillRectangle(
                fuelBrush,
                hudX,
                fuelY + barHeight - fuelFill,
                barWidth,
                fuelFill
            );

            // SCORE
            g.DrawString("SCORE", titleFont, Brushes.White, hudX, scoreY - 30);

            for (int i = 0; i < 7; i++)
            {
                Brush block = (score / 10) > i ? Brushes.Lime : Brushes.DimGray;
                g.FillRectangle(
                    block,
                    hudX,
                    scoreY + (6 - i) * 32,
                    barWidth,
                    26
                );
            }
        }

        // CALLED BY GAME OBJECTS
        public void OnEnemyCollision()
        {
            fuel -= 30;
            if (fuel < 0) fuel = 0;
        }

        public void OnBoosterCollected()
        {
            score += 10;
            if (score > maxScore) score = maxScore;
            framesWithoutBooster = 0;
        }
    }
}
