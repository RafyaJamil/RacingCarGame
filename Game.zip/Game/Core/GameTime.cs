﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core
{
    public class GameTime
    {
        // Time elapsed since the last update
        public float DeltaTime { get; set; } = 1f;
    }
}
